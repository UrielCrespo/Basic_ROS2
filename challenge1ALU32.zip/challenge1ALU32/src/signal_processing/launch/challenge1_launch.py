#!/usr/bin/env python3
"""
Launch File for Challenge 1
Starts:
- signal_generator node
- signal_processor node
- rqt_plot to visualize /signal and /proc_signal
"""

from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():
    # Nodo generador de señal
    signal_generator_node = Node(
        package='signal_processing',       # Tu paquete
        executable='signal_generator',     # Definido en setup.py
        name='signal_generator'
    )

    # Nodo procesador de señal
    signal_processor_node = Node(
        package='signal_processing',       
        executable='process',              
        name='signal_processor'
    )

    # Nodo rqt_plot para graficar ambas señales
    rqt_plot_node = Node(
        package='rqt_plot',
        executable='rqt_plot',
        name='rqt_plot',
        arguments=['/signal/data', '/proc_signal/data']
    )

    # Nodo rqt_graph
    rqt_graph_node = Node(
        package='rqt_graph',
        executable='rqt_graph',
        name='rqt_graph'
    )

    return LaunchDescription([
        signal_generator_node,
        signal_processor_node,
        rqt_plot_node,
        rqt_graph_node
    ])
