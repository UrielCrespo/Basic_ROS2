import math
import rclpy # Librería principal de ROS2 en Python (rclpy = ROS Client Library Python)
from rclpy.node import Node # Importa la clase base Node para crear nodos ROS2
from std_msgs.msg import Float32 # Importa el tipo de mensaje Float32 (un número flotante)


class SignalProcessor(Node):
    
    # 1) Constructor de la clase
    def __init__(self):

        # 2) Inicializacion del nodo ROS2
        super().__init__('signal_processor')

        # 3) Crear publishers
        self.publisher_process = self.create_publisher(Float32, '/proc_signal', 10)

        #) 4) Crear listeneralistener_callback
        self.subscription_signal = self.create_subscription(
            Float32,
            '/signal',
            self.signal_callback,
            10
        )

        self.subscription_time = self.create_subscription(
            Float32,
            '/time',
            self.time_callback,
            10
        )

        # 5) Inicializar ultimos valores leidos (signal y time)
        self.last_signal = None
        self.last_time = None
        
        #6) parametros de mi señal
        self.A = 1.0
        self.f = 0.5
        self.phi = math.pi / 4.0 # desfase

        # 7) Definir periodo del timer
        self.timer_period = 0.1

        # 8) Crear timer
        self.timer = self.create_timer(self.timer_period, self.timer_cb)

        # 9) log en terminal
        self.get_logger().info('SignalProcessor started: listening /signal & /time, publishing /proc_signal at 10 Hz')

    def signal_callback(self, msg : Float32):
        self.last_signal = float(msg.data)


    def time_callback(self, msg : Float32):
        self.last_time = float(msg.data)

    def timer_cb(self):

        # errores
        if self.last_signal is None or  self.last_time is None:
            return
                
        # Procesamiento
        # 1) Desfase
        y_shift = self.A * math.sin(2.0 * math.pi * self.f * self.last_time + self.phi)

        # 2) Reducir amplitud
        y_half = y_shift * 0.5

        # 3) offset
        y_proc = y_half + 0.5

        # Publicar resultado
        msg_process = Float32() 
        msg_process.data = float(y_proc)
        self.publisher_process.publish(msg_process)

        # 9) print to terminal
        self.get_logger().info(f'raw: {self.last_signal:+.3f} , process: {y_proc:.3f}')

def main(args = None):
        # 11) Inicializa rclpy (enciende ROS2 en este proceso)
        rclpy.init(args = args)

        # 12) Crea el nodo (aquí se ejecuta __init__ y se configuran publishers y timer)
        node = SignalProcessor()
        try:
            # 13) Mantiene el nodo vivo atendiendo callbacks (timer_cb) y eventos de ROS2
            rclpy.spin(node)
        except KeyboardInterrupt:
            # 14) Permite salir con Ctrl+C sin error feo
            pass
        finally:
            # 15) Limpia recursos del nodo (publishers, timers, etc.)
            node.destroy_node()
            # 16) Apaga ROS2 (cierra comunicaciones). rclpy.ok() verifica que no esté ya apagado.
            if rclpy.ok():
                rclpy.shutdown()
            

if __name__ == '__main__':
    main()
