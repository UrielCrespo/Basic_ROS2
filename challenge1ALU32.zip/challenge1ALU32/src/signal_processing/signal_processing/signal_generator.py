import math
import rclpy # Librería principal de ROS2 en Python (rclpy = ROS Client Library Python)
from rclpy.node import Node # Importa la clase base Node para crear nodos ROS2
from std_msgs.msg import Float32 # Importa el tipo de mensaje Float32 (un número flotante)

 # Clase de nodo llamada SignalGenerator que hereda de Node
class SignalGenerator(Node):
    # 1) Constructor de la clase
    def __init__(self):

        # 2) Inicializacion del nodo ROS2
        super().__init__('signal_generator')

        # 3) Crear publishers
        self.publisher_signal = self.create_publisher(Float32, '/signal', 10)
        self.publisher_time = self.create_publisher(Float32, '/time', 10)

        # 4) Definir el periodo del timer
        self.timer_period = 0.1

        # 5) crear timer
        self.timer = self.create_timer(self.timer_period, self.timer_cb)

        # variable de tiempo
        self.i = 0.0

        # 5) Parametros de la señal
        self.A = 1.0 # amplitude
        self.f = 0.5 # frecuency in Hz
     
        # 6) log en terminal
        self.get_logger().info('SignalGenerator started: publishing /signal and /time at 10 Hz')

    def timer_cb(self):

        # 6) Armar señal (generar)
        y = self.A * math.sin(2.0 * math.pi * self.f * self.i)

        # 7) Publish signal
        msg_signal = Float32() # Crear el objeto del mensaje
        msg_signal.data = float(y) # Asignar el valor numérico al campo "data"
        self.publisher_signal.publish(msg_signal) #  Publicar la señal en el topic /signal

        #8) Publish time
        msg_time = Float32()
        msg_time.data = float(self.i)
        self.publisher_time.publish(msg_time)

        # 9) print to terminal
        self.get_logger().info(f'time: {self.i:.2f} , y: {y:.3f}')

        # 10) avanzar tiempo a siguiente ciclo
        self.i += self.timer_period

def main(args = None):
        # 11) Inicializa rclpy (enciende ROS2 en este proceso)
        rclpy.init(args = args)

        # 12) Crea el nodo (aquí se ejecuta __init__ y se configuran publishers y timer)
        node = SignalGenerator()
        try:
            # 13) Mantiene el nodo vivo atendiendo callbacks (timer_cb) y eventos de ROS2
            rclpy.spin(node)
        except KeyboardInterrupt:
            # 14) Permite salir con Ctrl+C sin error feo
            pass
        finally:
            # 15) Limpia recursos del nodo (publishers, timers, etc.)
            node.destroy_node()
            # 16) Apaga ROS2 (cierra comunicaciones). rclpy.ok() verifica que no esté ya apagado.
            if rclpy.ok():
                rclpy.shutdown()
            

if __name__ == '__main__':
    main()






